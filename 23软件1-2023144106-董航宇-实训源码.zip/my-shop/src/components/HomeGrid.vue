<template>
  <div class="home-grid">
    <van-grid :column-num="3" square :gutter="10" border>
      <van-grid-item v-for="item in menulist" :key="item.id" @click="goToCategory(item.text)">
        <div class="grid-icon-wrap">
          <van-image :src="item.url" class="grid-icon" />
        </div>
        <span class="grid-text">{{ item.text }}</span>
      </van-grid-item>
    </van-grid>
  </div>
</template>

<script setup>
import { useRouter } from 'vue-router'
import menu1 from '../assets/images/menu1.png'
import menu2 from '../assets/images/menu2.png'
import menu3 from '../assets/images/menu3.png'
import menu4 from '../assets/images/menu4.png'
import menu5 from '../assets/images/menu5.png'
import menu6 from '../assets/images/menu6.png'
import menu7 from '../assets/images/menu7.png'
import menu8 from '../assets/images/menu8.png'
import menu9 from '../assets/images/menu9.png'
import menu10 from '../assets/images/menu10.png'

const router = useRouter()

const menulist = [
  { id: 1, text: '早餐', url: menu1 },
  { id: 2, text: '特色小吃', url: menu2 },
  { id: 3, text: '地域美食', url: menu3 },
  { id: 4, text: '中晚餐', url: menu4 },
  { id: 5, text: '餐后水果', url: menu5 },
  { id: 6, text: '其他', url: menu6 }
]

// goToCategory 跳转到点餐页并带上分类名称，点餐页会自动滚动到对应分类
const goToCategory = (name) => {
  // 跳转时带上分类名称
  router.push({
    name: 'category',
    query: { cname: name }
  })
}
</script>

<style lang="less" scoped> 
.home-grid {
  .van-grid-item {
    border: 1px solid #f0f0f0 !important;
    box-sizing: border-box;
    background: #fff;
  }
  .grid-icon-wrap {
    display: flex;
    justify-content: center;
    align-items: center;
    margin: 10px 0 4px 0;
  }
  .grid-icon {
    width: 48px;
    height: 48px;
    border-radius: 12px;
    box-shadow: 0 2px 8px #f0f1f2;
    background: #fff;
    object-fit: cover;
  }
  .grid-text {
    display: block;
    font-size: 14px;
    color: #333;
    margin-top: 2px;
    font-weight: 500;
    letter-spacing: 1px;
  }
}
</style>