<template>
  <div class="order-card">
    <div class="order-card-header">
      <span class="order-type" :style="{ background: order.typeColor }">{{ order.type }}</span>
      <span class="order-title">{{ order.title }}</span>
      <span class="order-status">{{ order.status }}</span>
    </div>
    <div class="order-foods">
      <div v-for="food in order.foods" :key="food.name" class="food-item">
        <img :src="food.img" class="food-img" />
        <div class="food-name">{{ food.name }}</div>
      </div>
    </div>
    <div class="order-summary">
      共{{ order.total }}件，实付￥{{ order.pay.toFixed(2) }}
    </div>
    <div class="order-card-footer">
      <div class="order-no">
        <span class="order-no-label">{{ order.orderNo }}</span>
        <span class="order-shop-status">{{ order.shopStatus }}</span>
      </div>
      <div class="order-actions">
        <div v-for="action in order.actions" :key="action.text" class="order-action">
          <van-icon :name="action.icon" size="20" />
          <span>{{ action.text }}</span>
        </div>
        <div v-if="showComplete" class="order-action complete" @click="handleComplete">
          <van-icon name="checked" size="20" />
          <span>完成</span>
        </div>
        <div v-if="showDelete" class="order-action delete" @click="handleDelete">
          <van-icon name="delete-o" size="20" />
          <span>删除</span>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue'

const props = defineProps({
  order: {
    type: Object,
    required: true
  },
  showComplete: {
    type: Boolean,
    default: false
  },
  showDelete: {
    type: Boolean,
    default: false
  }
})

const emit = defineEmits(['complete', 'delete'])

const handleComplete = () => {
  emit('complete', props.order.id)
}

const handleDelete = () => {
  emit('delete', props.order.id)
}
</script>

<style lang="less" scoped>
.order-card {
  background: #fff;
  border-radius: 12px;
  margin: 12px 12px 0 12px;
  box-shadow: 0 2px 8px #f0f1f2;
  padding: 12px 12px 8px 12px;
}
.order-card-header {
  display: flex;
  align-items: center;
  gap: 8px;
  margin-bottom: 8px;
  .order-type {
    color: #fff;
    font-size: 13px;
    border-radius: 6px;
    padding: 2px 10px;
    font-weight: bold;
  }
  .order-title {
    font-size: 15px;
    font-weight: bold;
    color: #222;
    margin-left: 8px;
    flex: 1;
  }
  .order-status {
    font-size: 13px;
    color: #ff8000;
    font-weight: bold;
  }
}
.order-foods {
  display: flex;
  align-items: center;
  gap: 16px;
  margin-bottom: 8px;
  .food-item {
    display: flex;
    flex-direction: column;
    align-items: center;
    .food-img {
      width: 48px;
      height: 48px;
      border-radius: 8px;
      object-fit: cover;
      margin-bottom: 2px;
    }
    .food-name {
      font-size: 13px;
      color: #666;
    }
  }
}
.order-summary {
  font-size: 13px;
  color: #888;
  margin-bottom: 8px;
  text-align: right;
}
.order-card-footer {
  display: flex;
  align-items: center;
  justify-content: space-between;
  border-top: 1px solid #f0f1f2;
  padding-top: 8px;
  .order-no {
    display: flex;
    flex-direction: column;
    .order-no-label {
      font-size: 14px;
      color: #222;
      font-weight: bold;
    }
    .order-shop-status {
      font-size: 12px;
      color: #888;
      margin-top: 2px;
    }
  }
  .order-actions {
    display: flex;
    gap: 18px;
    .order-action {
      display: flex;
      flex-direction: column;
      align-items: center;
      font-size: 12px;
      color: #888;
      cursor: pointer;
      span {
        margin-top: 2px;
      }
      &.complete {
        color: #07c160;
      }
      &.delete {
        color: #ee0a24;
      }
    }
  }
}
</style> 