<template>
  <div class="home-top">
    <h3>人气推荐</h3>
    <div class="content">
      <van-card
        v-for="item in GoodsList"
        :key="item.id"
        :tag="item.tag"
        :price="item.retail_price"
        :origin-price="item.origin_price"
        :desc="item.goods_brief"
        :title="item.name"
        :thumb="item.list_pic_url"
      >
      </van-card>
    </div>
  </div>
</template>

<script setup>
const GoodsList = [
  {
    retail_price: '12.9',
    name: '牛肉大堡',
    goods_brief: 'KBK人气第一',
    list_pic_url: '/images/top1.jpg',
    tag: 'TOP1'
  },
  {
    retail_price: '7.00',
    name: '南翔小笼包',
    goods_brief: '江南美食',
    list_pic_url: '/images/top2.jpg',
    tag: 'TOP2'
  },
  {
    retail_price: '14.88',
    origin_price: '18',
    name: '果碳烤鸭',
    goods_brief: '江理工美食',
    list_pic_url: '/images/top3.jpg',
    tag: 'TOP3'
  },
  {
    retail_price: '11.8',
    origin_price: '14',
    name: '猪肚鸡',
    goods_brief: '江理工美食力荐',
    list_pic_url: '/images/top4.jpg',
    tag: 'TOP4'
  },
  {
    retail_price: '16.9',
    name: '香酥琵琶腿3支',
    goods_brief: '榆林炸鸡腿力荐',
    list_pic_url: '/images/top5.jpg',
    tag: 'TOP5'
  }
]
</script>

<style lang="less" scoped>
.home-top {
  h3 {
    font-size: 22px;
    line-height: 30px;
    text-align: center;
    margin: 0.5rem 0;
  }
  .content {
    --van-tag-primary-color: #FF8000;
    --van-card-font-size: 16px;
    --van-card-background: #f9f9f9;
    background: var(--van-card-background);
    :deep(.van-card) {
      margin-top: 0;
      .van-card__title {
        padding: 10px 0 5px;
      }
      .van-card__price-currency {
        font-size: var(--van-card-font-size);
      }
    }
  }
  &::after {
    content: '';
    display: block;
    height: 3rem;
  }
}
</style>