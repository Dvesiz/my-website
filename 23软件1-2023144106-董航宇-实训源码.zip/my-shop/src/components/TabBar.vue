<template>
  <van-tabbar route fixed placeholder border>
    <van-tabbar-item replace :to="{ name: 'home' }" icon="home-o">首页</van-tabbar-item>
    <van-tabbar-item replace :to="{ name: 'category' }" icon="shop-o">点餐</van-tabbar-item>
    <van-tabbar-item replace :to="{ name: 'cart' }" icon="shopping-cart-o" :badge="cartCount()">餐车</van-tabbar-item>
    <van-tabbar-item replace :to="{ name: 'order' }" icon="orders-o">订单</van-tabbar-item>
    <van-tabbar-item replace :to="{ name: 'user' }" icon="user-o">我的</van-tabbar-item>
  </van-tabbar>
</template>

<script setup>
import useCart from '../stores/cart'

const { cartCount } = useCart()
</script>

<style scoped>
.van-tabbar-item {
  --van-tabbar-item-active-color: #FF8000;
}
</style>
