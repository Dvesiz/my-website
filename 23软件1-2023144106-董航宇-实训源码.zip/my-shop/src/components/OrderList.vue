<template>
  <div class="order-list">
    <van-pull-refresh v-model="refreshing" @refresh="onRefresh">
      <van-list
        v-model:loading="loading"
        :finished="finished"
        finished-text="没有更多了"
        @load="onLoad"
      >
        <div v-for="order in orders" :key="order.id" class="order-item">
          <div class="order-header">
            <span class="order-no">订单号：{{ order.order_no }}</span>
            <span class="order-status">{{ order.status_text }}</span>
          </div>
          <div class="order-goods">
            <van-card
              v-for="goods in order.goods"
              :key="goods.id"
              :num="goods.num"
              :price="goods.price"
              :title="goods.name"
              :thumb="goods.picture"
            />
          </div>
          <div class="order-footer">
            <div class="order-total">
              共{{ order.total_num }}件商品 合计：<span class="price">¥{{ order.total_price }}</span>
            </div>
            <div class="order-actions">
              <van-button v-if="order.status === 'pending'" type="danger" size="small" @click="onPay(order)">立即付款</van-button>
              <van-button v-if="order.status === 'shipped'" type="primary" size="small" @click="onConfirmReceive(order)">确认收货</van-button>
              <van-button v-if="order.status === 'completed'" type="default" size="small" @click="onReview(order)">评价</van-button>
              <van-button v-if="order.status === 'completed'" type="default" size="small" @click="onBuyAgain(order)">再次购买</van-button>
            </div>
          </div>
        </div>
      </van-list>
    </van-pull-refresh>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { showToast, showDialog } from 'vant'
import { getOrders, confirmOrder, payOrder } from '../api/order'

const props = defineProps({
  status: {
    type: String,
    default: 'all'
  }
})

// 列表加载状态
const loading = ref(false)
const finished = ref(false)
const refreshing = ref(false)
const page = ref(1)
const orders = ref([])

// 获取订单列表
const fetchOrders = async () => {
  try {
    const res = await getOrders({
      status: props.status,
      page: page.value,
      limit: 10
    })
    
    if (refreshing.value) {
      orders.value = []
      refreshing.value = false
    }
    
    orders.value.push(...res.data)
    loading.value = false
    
    if (res.data.length < 10) {
      finished.value = true
    } else {
      page.value++
    }
  } catch (error) {
    showToast('获取订单列表失败')
    loading.value = false
    finished.value = true
  }
}

// 下拉刷新
const onRefresh = () => {
  finished.value = false
  page.value = 1
  loading.value = true
  fetchOrders()
}

// 加载更多
const onLoad = () => {
  fetchOrders()
}

// 立即付款
const onPay = async (order) => {
  try {
    await showDialog({
      title: '确认支付',
      message: `是否确认支付订单 ${order.order_no}？`,
      showCancelButton: true
    })
    
    await payOrder(order.id)
    showToast('支付成功')
    onRefresh()
  } catch (error) {
    if (error !== 'cancel') {
      showToast('支付失败')
    }
  }
}

// 确认收货
const onConfirmReceive = async (order) => {
  try {
    await showDialog({
      title: '确认收货',
      message: `是否确认已收到订单 ${order.order_no} 的商品？`,
      showCancelButton: true
    })
    
    await confirmOrder(order.id)
    showToast('确认收货成功')
    onRefresh()
  } catch (error) {
    if (error !== 'cancel') {
      showToast('确认收货失败')
    }
  }
}

// 评价
const onReview = (order) => {
  // TODO: 跳转到评价页面
  showToast('评价功能开发中')
}

// 再次购买
const onBuyAgain = (order) => {
  // TODO: 将商品添加到购物车
  showToast('再次购买功能开发中')
}

onMounted(() => {
  fetchOrders()
})
</script>

<style lang="less" scoped>
.order-list {
  padding: 10px;
}

.order-item {
  margin-bottom: 10px;
  background-color: #fff;
  border-radius: 8px;
  overflow: hidden;
}

.order-header {
  padding: 10px;
  display: flex;
  justify-content: space-between;
  border-bottom: 1px solid #eee;
  
  .order-no {
    color: #666;
    font-size: 14px;
  }
  
  .order-status {
    color: #ff6b6b;
    font-size: 14px;
  }
}

.order-goods {
  padding: 10px;
}

.order-footer {
  padding: 10px;
  border-top: 1px solid #eee;
  
  .order-total {
    text-align: right;
    margin-bottom: 10px;
    
    .price {
      color: #ff6b6b;
      font-weight: bold;
    }
  }
  
  .order-actions {
    display: flex;
    justify-content: flex-end;
    gap: 10px;
  }
}
</style> 