// 导入 Vue Router 相关函数
import { createRouter, createWebHistory } from 'vue-router'

// 创建路由实例
const router = createRouter({
  // 使用 HTML5 History 模式
  history: createWebHistory(),
  // 路由配置
  routes: [
    { 
        path: '/', 
        redirect: '/home', // 根路径重定向到首页
        meta: { title: '首页' }
      },
      { 
        path: '/home',
        name: 'home',
        component: () => import('../pages/Home.vue'), // 懒加载首页组件
        meta: { title: '首页', name: 'home', isTab: true } // 显示底部导航栏
      },
      { 
        path: '/category', 
        component: () => import('../pages/Category.vue'), // 懒加载分类页组件
        name: 'category',
        meta: { title: '分类', isTab: true, isShowNav: true } // 显示顶部和底部导航栏
      },
      
      {
        path: '/cart' ,
        component: () => import('../pages/Cart.vue'), // 懒加载购物车组件
        name: 'cart' ,
        meta: { title: '购物车', isTab: true, isShowNav: true, isShowBack: true } // 显示返回按钮
      },
      { 
        path: '/user', 
        component: () => import('../pages/User.vue'), // 懒加载用户中心组件
        name: 'user', 
        meta: { title: '我的', isTab: true }
      },
      { 
        path: '/login',
        component: () => import('../pages/Login.vue'), // 懒加载登录页组件
        name: 'login', 
        meta: { title: '登录', isTab: true, isShowNav: true, isShowBack: true }
      },
      { 
        path: '/register', 
        component: () => import('../pages/Register.vue'), // 懒加载注册页组件
        name: 'register', 
        meta: { title: '注册', isTab: true, isShowNav: true, isShowBack: true }
      },
     
      { 
        path: '/goodsDetail/:id', // 动态路由参数
        component: () => import('../pages/GoodsDetail.vue'), 
        props: true,
        name: 'goodsDetail', 
        meta: { title: '商品详情', isTab: false, isShowNav: true, isShowBack: true }
      },
      { 
        path: '/order', 
        component: () => import('../pages/Order.vue'), // 懒加载订单页组件
        name: 'order', 
        meta: { title: '我的订单', isTab: false, isShowNav: true, isShowBack: true }
      },
      { 
        path: '/payment', 
        component: () => import('../pages/Payment.vue'), // 懒加载支付页组件
        name: 'payment', 
        meta: { title: '确认订单', isTab: false, isShowNav: true, isShowBack: true }
      }
  ]
})

// 全局前置守卫
router.beforeEach((to, from, next) => {
  // 设置页面标题
  const title = to.meta && to.meta.title
  if (title) {
    document.title = title
  }
  next() 
})

export default router