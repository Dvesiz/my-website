import request from '../utils/request'

// 获取订单列表
export function getOrders(params) {
  return request({
    url: '/order/list',
    method: 'get',
    params
  })
}

// 获取订单详情
export function getOrderDetail(id) {
  return request({
    url: `/order/detail/${id}`,
    method: 'get'
  })
}

// 创建订单
export function createOrder(data) {
  return request({
    url: '/order/create',
    method: 'post',
    data
  })
}

// 支付订单
export function payOrder(id) {
  return request({
    url: `/order/pay/${id}`,
    method: 'post'
  })
}

// 确认收货
export function confirmOrder(id) {
  return request({
    url: `/order/confirm/${id}`,
    method: 'post'
  })
}

// 取消订单
export function cancelOrder(id) {
  return request({
    url: `/order/cancel/${id}`,
    method: 'post'
  })
}

// 删除订单
export function deleteOrder(id) {
  return request({
    url: `/order/delete/${id}`,
    method: 'post'
  })
}

// 评价订单
export function reviewOrder(id, data) {
  return request({
    url: `/order/review/${id}`,
    method: 'post',
    data
  })
} 