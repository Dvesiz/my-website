<template>
  <!-- 顶部导航栏 -->
  <van-nav-bar
    :title="$route.meta.title"
    v-show="$route.meta.isShowNav"
    @click-left="onClickLeft"
    :left-arrow="$route.meta.isShowBack"
    fixed
    placeholder
    style="height: 46px"
  />
  <!-- 路由视图 -->
  <router-view></router-view>
  <!-- 底部导航栏 -->
  <tab-bar v-if="isShowTabbar"></tab-bar>
</template>

<script setup>
// 导入组件和函数
import TabBar from './components/TabBar.vue'
import { useRoute } from 'vue-router'
import { ref, watch, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import { getUser } from './api'
import useUser from './stores/user'

// 路由实例
const route = useRoute()
const router = useRouter()

// 控制底部导航栏显示
const isShowTabbar = ref(true)

// 返回按钮点击事件
const onClickLeft = () => {
  if (history.length > 1) {
    router.back()
  } else {
    router.push({ name: 'home' })
  }
}

// 监听路由元信息变化
watch(
  () => route.meta,
  val => {
    isShowTabbar.value = val.isTab
  }
)

// 获取用户信息相关方法
const { user, updateUser } = useUser()

// 组件挂载时检查登录状态
onMounted(() => {
  if (user.isLogin) {
    loadUser()
  }
})

// 加载用户信息
const loadUser = async () => {
  const data = await getUser()
  updateUser({
    isLogin: true,
    username: data.username,
    avatar: data.avatar
  })
}
</script>

<style>
/* 全局样式 */
#app {
  color: #2c3e50;
  line-height: 24px;
  /* 导航栏样式 */
  --van-nav-bar-background: #ff8000;
  --van-nav-bar-title-text-color: #fff;
  --van-nav-bar-icon-color: #fff;
}
</style>
