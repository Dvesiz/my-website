<template>
  <div class="order-container">
    <div class="order-header">
      <h2>确认订单</h2>
    </div>
    
    <!-- 订单信息 -->
    <div class="order-info">
      <div class="address-info">
        <h3>收货地址</h3>
        <div class="address-card" v-if="address">
          <p>{{ address.name }} {{ address.phone }}</p>
          <p>{{ address.province }} {{ address.city }} {{ address.district }}</p>
          <p>{{ address.detail }}</p>
        </div>
        <div class="no-address" v-else>
          <el-button type="primary" @click="showAddressDialog">添加收货地址</el-button>
        </div>
      </div>

      <div class="goods-info">
        <h3>商品信息</h3>
        <div class="goods-list">
          <div v-for="item in orderItems" :key="item.id" class="goods-item">
            <img :src="item.image" :alt="item.name">
            <div class="goods-detail">
              <h4>{{ item.name }}</h4>
              <p class="price">¥{{ item.price }}</p>
              <p class="quantity">x{{ item.quantity }}</p>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- 支付方式 -->
    <div class="payment-methods">
      <h3>支付方式</h3>
      <div class="payment-options">
        <div 
          v-for="method in paymentMethods" 
          :key="method.id"
          :class="['payment-option', { active: selectedPayment === method.id }]"
          @click="selectPayment(method.id)"
        >
          <img :src="method.icon" :alt="method.name">
          <span>{{ method.name }}</span>
        </div>
      </div>
    </div>

    <!-- 订单金额 -->
    <div class="order-amount">
      <div class="amount-item">
        <span>商品总额</span>
        <span>¥{{ totalAmount }}</span>
      </div>
      <div class="amount-item">
        <span>运费</span>
        <span>¥{{ shippingFee }}</span>
      </div>
      <div class="amount-item total">
        <span>实付金额</span>
        <span class="price">¥{{ finalAmount }}</span>
      </div>
    </div>

    <!-- 提交订单 -->
    <div class="submit-order">
      <el-button type="primary" size="large" @click="submitOrder" :disabled="!canSubmit">
        提交订单
      </el-button>
    </div>
  </div>
</template>

<script setup>
import { ref, computed } from 'vue'
import { ElMessage } from 'element-plus'
import { createOrder, wechatPay, alipay, queryPaymentStatus } from '@/services/payment'
import { useRouter } from 'vue-router'

const router = useRouter()
// 模拟数据
const address = ref(null)
const orderItems = ref([
  {
    id: 1,
    name: '示例商品1',
    price: 99.00,
    quantity: 1,
    image: '/images/product1.jpg'
  }
])

const paymentMethods = ref([
  {
    id: 'wechat',
    name: '微信支付',
    icon: '/images/wechat-pay.png'
  },
  {
    id: 'alipay',
    name: '支付宝',
    icon: '/images/alipay.png'
  },
  {
    id: 'cash',
    name: '货到付款',
    icon: '/images/cash.png'
  }
])

const selectedPayment = ref('')
const shippingFee = ref(10)

// 计算属性
const totalAmount = computed(() => {
  return orderItems.value.reduce((sum, item) => sum + item.price * item.quantity, 0)
})

const finalAmount = computed(() => {
  return totalAmount.value + shippingFee.value
})

const canSubmit = computed(() => {
  return address.value && selectedPayment.value
})

// 方法
const showAddressDialog = () => {
  // 实现地址选择弹窗
  ElMessage.info('打开地址选择')
}

const selectPayment = (methodId) => {
  selectedPayment.value = methodId
}

const submitOrder = async () => {
  if (!canSubmit.value) {
    ElMessage.warning('请完善订单信息')
    return
  }

  try {
    // 创建订单
    const orderData = {
      address: address.value,
      items: orderItems.value,
      paymentMethod: selectedPayment.value,
      totalAmount: finalAmount.value
    }
    
    const order = await createOrder(orderData)
    
    // 根据支付方式处理支付
    if (selectedPayment.value === 'wechat') {
      const payResult = await wechatPay(order.id)
      // 处理微信支付结果
      if (payResult.success) {
        // 跳转到微信支付页面或显示二维码
        window.location.href = payResult.payUrl
      }
    } else if (selectedPayment.value === 'alipay') {
      const payResult = await alipay(order.id)
      // 处理支付宝支付结果
      if (payResult.success) {
        // 跳转到支付宝支付页面
        window.location.href = payResult.payUrl
      }
    } else if (selectedPayment.value === 'cash') {
      // 货到付款，直接跳转到订单详情页
      ElMessage.success('订单提交成功')
      router.push(`/order/${order.id}`)
    }

    // 开始轮询支付状态
    if (selectedPayment.value !== 'cash') {
      const checkPaymentStatus = async () => {
        const status = await queryPaymentStatus(order.id)
        if (status.paid) {
          ElMessage.success('支付成功')
          router.push(`/order/${order.id}`)
        } else if (status.status === 'failed') {
          ElMessage.error('支付失败')
        } else {
          // 继续轮询
          setTimeout(checkPaymentStatus, 3000)
        }
      }
      checkPaymentStatus()
    }
  } catch (error) {
    ElMessage.error(error.message || '订单提交失败')
  }
}
</script>

<style scoped>
.order-container {
  max-width: 1200px;
  margin: 0 auto;
  padding: 20px;
}

.order-header {
  margin-bottom: 30px;
}

.order-info {
  background: #fff;
  border-radius: 8px;
  padding: 20px;
  margin-bottom: 20px;
}

.address-info {
  margin-bottom: 20px;
}

.address-card {
  border: 1px solid #eee;
  padding: 15px;
  border-radius: 4px;
}

.goods-list {
  margin-top: 15px;
}

.goods-item {
  display: flex;
  padding: 15px 0;
  border-bottom: 1px solid #eee;
}

.goods-item img {
  width: 80px;
  height: 80px;
  object-fit: cover;
  margin-right: 15px;
}

.goods-detail {
  flex: 1;
}

.payment-methods {
  background: #fff;
  border-radius: 8px;
  padding: 20px;
  margin-bottom: 20px;
}

.payment-options {
  display: flex;
  gap: 20px;
  margin-top: 15px;
}

.payment-option {
  display: flex;
  align-items: center;
  padding: 10px 20px;
  border: 1px solid #eee;
  border-radius: 4px;
  cursor: pointer;
}

.payment-option.active {
  border-color: #409EFF;
  background: #ecf5ff;
}

.payment-option img {
  width: 24px;
  height: 24px;
  margin-right: 8px;
}

.order-amount {
  background: #fff;
  border-radius: 8px;
  padding: 20px;
  margin-bottom: 20px;
}

.amount-item {
  display: flex;
  justify-content: space-between;
  margin-bottom: 10px;
}

.amount-item.total {
  border-top: 1px solid #eee;
  padding-top: 10px;
  margin-top: 10px;
  font-weight: bold;
}

.amount-item.total .price {
  color: #f56c6c;
  font-size: 20px;
}

.submit-order {
  text-align: right;
  padding: 20px 0;
}

.submit-order .el-button {
  width: 200px;
}
</style> 