<template>
  <div class="user-page">
    <div class="user-header">
      <div class="user-title">我的</div>
      <div class="user-header-icons">
        <van-icon name="ellipsis" size="24" />
      </div>
    </div>
    <template v-if="user.isLogin">
      <div class="user-card">
        <div class="avatar-upload" @click="showUploader = true">
          <img class="avatar" :src="user.avatar || avatar_default" />
          <div class="avatar-mask">更换头像</div>
        </div>
        <van-uploader v-model="fileList" :after-read="onAfterRead" :show-upload="false" :max-count="1" accept="image/*" v-show="showUploader" @close="showUploader = false" />
        <div class="user-info">
          <div class="nickname">Hi,{{ user.username }}</div>
          <div class="level-bar">
            <span class="level">V1</span>
            <van-progress :percentage="12 / 2" color="#ff8000" stroke-width="6px" show-pivot="false" />
            <span class="growth">成长值12/200</span>
          </div>
        </div>
      </div>
      <div class="user-stats">
        <div class="stat-item">
          <div class="stat-value">2031.7</div>
          <div class="stat-label">累计消费</div>
        </div>
        <div class="stat-item">
          <div class="stat-value">68</div>
          <div class="stat-label">饭卡余额</div>
        </div>
        <div class="stat-item">
          <div class="stat-value">1</div>
          <div class="stat-label">优惠券</div>
        </div>
      </div>
      <van-cell-group class="user-list">
        <van-cell title="收货地址" icon="location-o" is-link />
        <van-cell title="饭卡充值" icon="balance-o" is-link />
        <van-cell title="评论管理" icon="comment-o" is-link />
        <van-cell title="商家入驻" icon="shop-o" is-link />
        <van-cell title="兼职管理" icon="manager-o" is-link />
        <van-cell title="开始跑腿" icon="flag-o" is-link />
      </van-cell-group>
      <div class="logout-btn-wrap">
        <van-button block round type="danger" @click="onLogout">退出登录</van-button>
      </div>
    </template>
    <template v-else>
      <div class="user-card user-card-center">
        <img class="avatar" :src="avatar_default" />
        <div class="user-info">
          <div class="nickname">Hi, 游客</div>
        </div>
      </div>
      <div class="login-btns">
        <van-button block round type="primary" @click="goLogin">登录</van-button>
        <van-button block round type="default" style="margin-top: 12px;" @click="goRegister">注册</van-button>
      </div>
    </template>
  </div>
</template>

<script setup>
import { ref } from 'vue'
import { useRouter } from 'vue-router'
import useUser from '../stores/user'
import useToken from '../stores/token'
import avatar_default from '../assets/images/avatar_default.png'
import { showToast } from 'vant'

const { user, removeUser, setAvatar } = useUser()
const { removeToken } = useToken()
const router = useRouter()

const showUploader = ref(false)
const fileList = ref([])

const onAfterRead = (file) => {
  // 本地预览
  if (file instanceof Array) file = file[0]
  const reader = new FileReader()
  reader.onload = (e) => {
    user.avatar = e.target.result
    setAvatar && setAvatar(e.target.result) // 如果有pinia方法
    showToast('头像已更新')
    showUploader.value = false
  }
  reader.readAsDataURL(file.file)
}

const goLogin = () => {
  router.push({ name: 'login' })
}
const goRegister = () => {
  router.push({ name: 'register' })
}
const onLogout = () => {
  removeToken()
  removeUser()
  showToast('已退出登录')
}
</script>

<style lang="less" scoped>
.user-page {
  min-height: 100vh;
  background: #f7f8fa;
}
.user-header {
  background: #ff8000;
  height: 90px;
  position: relative;
  .user-title {
    color: #fff;
    font-size: 22px;
    font-weight: bold;
    text-align: center;
    line-height: 90px;
    letter-spacing: 2px;
  }
  .user-header-icons {
    position: absolute;
    right: 20px;
    top: 32px;
    color: #fff;
  }
}
.user-card {
  background: #fff;
  border-radius: 12px;
  box-shadow: 0 2px 8px #f0f1f2;
  margin: -40px 16px 0 16px;
  padding: 16px 16px 10px 16px;
  display: flex;
  align-items: center;
  position: relative;
  z-index: 2;
  .avatar-upload {
    position: relative;
    display: inline-block;
    cursor: pointer;
    .avatar {
      width: 64px;
      height: 64px;
      border-radius: 50%;
      object-fit: cover;
      border: 3px solid #fff;
      box-shadow: 0 2px 8px #f0f1f2;
    }
    .avatar-mask {
      position: absolute;
      left: 0; top: 0;
      width: 64px; height: 64px;
      background: rgba(0,0,0,0.3);
      color: #fff;
      font-size: 13px;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      opacity: 0;
      transition: opacity 0.2s;
    }
    &:hover .avatar-mask {
      opacity: 1;
    }
  }
  .user-info {
    margin-left: 16px;
    flex: 1;
    .nickname {
      font-size: 18px;
      font-weight: bold;
      color: #333;
      margin-bottom: 6px;
    }
    .level-bar {
      display: flex;
      align-items: center;
      gap: 8px;
      .level {
        background: #ff8000;
        color: #fff;
        border-radius: 8px;
        font-size: 12px;
        padding: 2px 8px;
        margin-right: 4px;
      }
      .growth {
        font-size: 12px;
        color: #888;
        margin-left: 8px;
      }
    }
  }
}
.user-card-center {
  justify-content: center;
}
.user-stats {
  display: flex;
  background: #fff;
  border-radius: 12px;
  margin: 12px 16px 0 16px;
  box-shadow: 0 2px 8px #f0f1f2;
  padding: 12px 0;
  justify-content: space-around;
  .stat-item {
    text-align: center;
    .stat-value {
      font-size: 20px;
      color: #ff8000;
      font-weight: bold;
    }
    .stat-label {
      font-size: 13px;
      color: #888;
      margin-top: 2px;
    }
  }
}
.user-list {
  margin: 16px;
  border-radius: 12px;
  overflow: hidden;
  background: #fff;
  box-shadow: 0 2px 8px #f0f1f2;
}
.login-btns {
  margin: 32px 16px 0 16px;
}
.logout-btn-wrap {
  margin: 24px 16px 0 16px;
}
</style>
