<template>
  <div class="payment-page">
    <van-nav-bar
      title="确认订单"
      left-arrow
      @click-left="onClickLeft"
    />
    
    <div class="order-info">
      <van-cell-group>
        <van-cell title="商品信息">
          <template #value>
            <div class="goods-info">
              <img :src="orderInfo.goodsImg" class="goods-img" />
              <div class="goods-detail">
                <div class="goods-name">{{ orderInfo.goodsName }}</div>
                <div class="goods-price">￥{{ orderInfo.price }}</div>
              </div>
            </div>
          </template>
        </van-cell>
        <van-cell title="订单类型">
          <template #value>
            <van-radio-group v-model="orderType" direction="horizontal">
              <van-radio name="堂食" icon-size="18px">堂食</van-radio>
              <van-radio name="打包带走" icon-size="18px">打包带走</van-radio>
            </van-radio-group>
          </template>
        </van-cell>
        <van-cell title="配送方式" value="校园配送" />
        <van-cell title="支付方式">
          <template #value>
            <van-radio-group v-model="paymentMethod">
              <van-radio name="wechat">微信支付</van-radio>
              <van-radio name="alipay">支付宝</van-radio>
            </van-radio-group>
          </template>
        </van-cell>
      </van-cell-group>
    </div>

    <div class="price-info">
      <van-cell-group>
        <van-cell title="商品金额" :value="'￥' + orderInfo.price" />
        <van-cell title="配送费" value="￥1" />
        <van-cell title="实付金额" :value="'￥' + (orderInfo.price + 1)" />
      </van-cell-group>
    </div>

    <div class="submit-bar">
      <van-submit-bar
        :price="(orderInfo.price + 1) * 100"
        button-text="提交订单"
        @submit="onSubmit"
      />
    </div>
  </div>
</template>

<script setup>
import { ref, reactive } from 'vue'
import { useRouter, useRoute } from 'vue-router'
import { showToast, showSuccessToast } from 'vant'

const router = useRouter()
const route = useRoute()

const paymentMethod = ref('wechat')
const orderType = ref('堂食')

const orderInfo = reactive({
  goodsName: route.query.goodsName || '商品名称',
  goodsImg: route.query.goodsImg || '/images/default.jpg',
  price: Number(route.query.price) || 0,
  type: route.query.type || '堂食',
  typeColor: route.query.typeColor || '#ff8000',
  foods: route.query.foods ? JSON.parse(route.query.foods) : []
})

const onClickLeft = () => {
  router.back()
}

const onSubmit = () => {
  showSuccessToast('支付成功')
  setTimeout(() => {
    router.push({
      path: '/order',
      query: {
        goodsName: orderInfo.goodsName,
        goodsImg: orderInfo.goodsImg,
        price: orderInfo.price,
        type: orderInfo.type,
        typeColor: orderInfo.typeColor,
        foods: route.query.foods
      }
    })
  }, 1500)
}
</script>

<style lang="less" scoped>
.payment-page {
  min-height: 100vh;
  background: #f7f8fa;
  padding-bottom: 50px;
}

.order-info {
  margin: 12px 0;
  
  .goods-info {
    display: flex;
    align-items: center;
    
    .goods-img {
      width: 80px;
      height: 80px;
      margin-right: 12px;
      border-radius: 4px;
    }
    
    .goods-detail {
      flex: 1;
      text-align: left;
      
      .goods-name {
        font-size: 14px;
        margin-bottom: 8px;
      }
      
      .goods-price {
        color: #f44;
        font-size: 16px;
      }
    }
  }
}

.price-info {
  margin: 12px 0;
}

.submit-bar {
  position: fixed;
  bottom: 0;
  left: 0;
  width: 100%;
}

:deep(.van-radio-group) {
  display: flex;
  gap: 20px;
}

:deep(.van-radio__label) {
  color: #323233;
}
</style> 