<template>
    <div class="order-page">
      <van-tabs v-model:active="activeTab" class="order-tabs">
        <van-tab title="进行中">
          <div class="order-list">
            <OrderCard 
              v-for="order in doingOrders" 
              :key="order.id" 
              :order="order"
              :show-complete="true"
              @complete="handleComplete"
            />
          </div>
        </van-tab>
        <van-tab title="历史订单">
          <div class="order-list" v-if="historyOrders.length > 0">
            <OrderCard 
              v-for="order in historyOrders" 
              :key="order.id" 
              :order="order"
              :show-delete="true"
              @delete="handleDelete"
            />
          </div>
          <div class="order-list empty" v-else>暂无历史订单</div>
        </van-tab>
        <van-tab title="线下订单">
          <div class="order-list" v-if="offlineOrders.length > 0">
            <OrderCard 
              v-for="order in offlineOrders" 
              :key="order.id" 
              :order="order"
              :show-delete="true"
              @delete="handleDeleteOffline"
            />
          </div>
          <div class="order-list empty" v-else>暂无线下订单</div>
        </van-tab>
      </van-tabs>
      <TabBar />
    </div>
  </template>
  
  <script setup>
  import { ref, onMounted } from 'vue'
  import TabBar from '../components/TabBar.vue'
  import OrderCard from '../components/OrderCard.vue'
  import { useRoute } from 'vue-router'
  import { showSuccessToast, showDialog } from 'vant'
  
  const route = useRoute()
  const activeTab = ref(0)
  
  // 从localStorage获取订单数据
  const getStoredOrders = () => {
    const storedDoingOrders = localStorage.getItem('doingOrders')
    const storedHistoryOrders = localStorage.getItem('historyOrders')
    const storedOfflineOrders = localStorage.getItem('offlineOrders')
    return {
      doingOrders: storedDoingOrders ? JSON.parse(storedDoingOrders) : [],
      historyOrders: storedHistoryOrders ? JSON.parse(storedHistoryOrders) : [],
      offlineOrders: storedOfflineOrders ? JSON.parse(storedOfflineOrders) : []
    }
  }
  
  // 保存订单数据到localStorage
  const saveOrders = (doingOrders, historyOrders, offlineOrders) => {
    localStorage.setItem('doingOrders', JSON.stringify(doingOrders))
    localStorage.setItem('historyOrders', JSON.stringify(historyOrders))
    localStorage.setItem('offlineOrders', JSON.stringify(offlineOrders))
  }
  
  // 初始化订单数据
  const { doingOrders: storedDoingOrders, historyOrders: storedHistoryOrders, offlineOrders: storedOfflineOrders } = getStoredOrders()
  
  const doingOrders = ref(storedDoingOrders.length > 0 ? storedDoingOrders : [
    {
      id: 1,
      type: '堂食',
      typeColor: '#ff8000',
      status: '制作中',
      title: '酷堡王',
      foods: [
        { name: '牛肉大堡', img: '/images/top1.jpg' },
        { name: '薯条大份', img: '/images/kbk2.jpg' },
        { name: '新奥尔良对翅', img: '/images/kbk3.jpg' }
      ],
      total: 3,
      pay: 31.7,
      orderNo: 'D0001',
      shopStatus: '商家正在备餐中',
      actions: [
        { icon: 'phone-o', text: '联系' },
        { icon: 'comment-o', text: '留言' }
      ]
    },
    {
      id: 2,
      type: '打包带走',
      typeColor: '#ff4d30',
      status: '待取餐',
      title: '闫阿妈拌饭',
      foods: [
        { name: '五花肉拌饭', img: '/images/yam1.jpg' },
        { name: '全家福拌饭', img: '/images/yam2.jpg' },
        { name: '香肉双拼拌饭', img: '/images/yam3.jpg' }
      ],
      total: 3,
      pay: 32.4,
      orderNo: 'D0001',
      shopStatus: '待取餐',
      actions: [
        { icon: 'phone-o', text: '联系' },
        { icon: 'comment-o', text: '留言' }
      ]
    }
  ])
  
  const historyOrders = ref(storedHistoryOrders)
  const offlineOrders = ref(storedOfflineOrders)
  
  // 处理新订单
  const handleNewOrder = () => {
    const newOrder = route.query
    if (newOrder.goodsName) {
      let foods = []
      if (newOrder.foods) {
        try {
          foods = JSON.parse(newOrder.foods)
        } catch (e) {
          foods = [{ 
            name: newOrder.goodsName, 
            img: newOrder.goodsImg || '/images/default.jpg'
          }]
        }
      } else {
        foods = [{ 
          name: newOrder.goodsName, 
          img: newOrder.goodsImg || '/images/default.jpg'
        }]
      }
  
      const order = {
        id: Date.now(),
        type: newOrder.type || '堂食',
        typeColor: newOrder.typeColor || '#ff8000',
        status: '制作中',
        title: '校园食堂',
        foods: foods,
        total: foods.length,
        pay: Number(newOrder.price) + 1,
        orderNo: `D${String(doingOrders.value.length + 1).padStart(4, '0')}`,
        shopStatus: '商家正在备餐中',
        actions: [
          { icon: 'phone-o', text: '联系' },
          { icon: 'comment-o', text: '留言' }
        ],
        isOffline: newOrder.isOffline === 'true'
      }
      doingOrders.value.unshift(order)
      saveOrders(doingOrders.value, historyOrders.value, offlineOrders.value)
    }
  }
  
  // 处理完成订单
  const handleComplete = (orderId) => {
    const orderIndex = doingOrders.value.findIndex(order => order.id === orderId)
    if (orderIndex !== -1) {
      const completedOrder = { ...doingOrders.value[orderIndex] }
      completedOrder.status = '已完成'
      completedOrder.shopStatus = '订单已完成'
      
      // 添加到历史订单
      historyOrders.value.unshift(completedOrder)
      
      // 如果是线下订单，同时添加到线下订单列表
      if (completedOrder.isOffline) {
        offlineOrders.value.unshift(completedOrder)
      }
      
      doingOrders.value.splice(orderIndex, 1)
      saveOrders(doingOrders.value, historyOrders.value, offlineOrders.value)
      showSuccessToast('订单已完成')
    }
  }
  
  // 处理删除历史订单
  const handleDelete = (orderId) => {
    showDialog({
      title: '删除订单',
      message: '确定要删除这个订单吗？',
      showCancelButton: true,
    }).then(() => {
      const orderIndex = historyOrders.value.findIndex(order => order.id === orderId)
      if (orderIndex !== -1) {
        historyOrders.value.splice(orderIndex, 1)
        saveOrders(doingOrders.value, historyOrders.value, offlineOrders.value)
        showSuccessToast('删除成功')
      }
    }).catch(() => {
      // 取消删除
    })
  }
  
  // 处理删除线下订单
  const handleDeleteOffline = (orderId) => {
    showDialog({
      title: '删除订单',
      message: '确定要删除这个订单吗？',
      showCancelButton: true,
    }).then(() => {
      const orderIndex = offlineOrders.value.findIndex(order => order.id === orderId)
      if (orderIndex !== -1) {
        offlineOrders.value.splice(orderIndex, 1)
        saveOrders(doingOrders.value, historyOrders.value, offlineOrders.value)
        showSuccessToast('删除成功')
      }
    }).catch(() => {
      // 取消删除
    })
  }
  
  onMounted(() => {
    handleNewOrder()
  })
  </script>
  
  <style lang="less" scoped>
  .order-page {
    min-height: 100vh;
    background: #f7f8fa;
    padding-bottom: 60px;
  }
  .order-tabs {
    background: #fff;
  }
  .order-list {
    padding: 0 0 8px 0;
  }
  .empty {
    text-align: center;
    color: #999;
    padding: 40px 0;
  }
  </style> 